<?php
/**
 * @file
 *
 * Theme file for an empty cart.
 */
?>
<div id="cart-block-contents-ajax" class="cart-empty">
  <?php print t('No products in cart');?>
</div>